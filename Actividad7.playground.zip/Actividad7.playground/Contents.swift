import UIKit

//Aplicar impuesto a la colección costo_referencia
var costo_referencia:[Float] = [8.3,10.5,9.9]
var indice:Int = 0

for i in costo_referencia {
    costo_referencia[indice] = i*0.16
    indice += 1
}
costo_referencia

//Funcion impuesto
func impuesto(arreglo:[Float])->[Float]{
    var resultado:[Float] = []
    for i in arreglo {
        resultado.append(i*0.16)
    }
    return resultado
}

impuesto(arreglo: costo_referencia)
costo_referencia

//funcion sumatres
let Suma = {(x:Int , y:Int) -> Int in return x + y}
Suma (5,8)

func sumaTres(a:Int , b:Int , c:Int) -> Int {
    return Suma(a,b) + c
}
sumaTres(a: 5, b: 8, c: 2)

//Funcion del cambio entre valores
func CambioUno(a:inout Int , b:inout Int) -> (Int, Int) {
    let temp = a
    a = b
    b = temp
    return (a,b)
}

func CambioDos(a: inout String , b:inout String) -> (String, String) {
    let temp = a
    a = b
    b = temp
    return (a,b)
}


//Funcion Transformar
extension Array{
    func Transformar<T>(inicial:T, acumula:(T, Element) -> T) -> T {
        var respuesta:T = inicial
        for valor in self {
            respuesta = acumula(respuesta, valor)
        }
        return respuesta
    }
}

var datos = [3,7,9,2]
var letras = ["a" , "b" , "c" , "d" , "e"]
datos.Transformar(inicial: 0) { (a, b) in a + b}
letras.Transformar(inicial: "") {(a, b) in a + b}

//Swift Map
var precios = [4.2, 5.3, 8.2, 4.5]
var impuesto = precios.map{a in return a * 0.16 * a}
impuesto
//Swift filter
var precio_menor = precios.filter{a in a > 6.0}
precio_menor
